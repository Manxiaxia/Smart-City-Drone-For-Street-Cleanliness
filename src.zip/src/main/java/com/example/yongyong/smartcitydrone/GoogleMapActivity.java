package com.example.yongyong.smartcitydrone;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.EventLog;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import dji.common.error.DJIError;
import dji.common.flightcontroller.FlightControllerState;
import dji.common.mission.waypoint.Waypoint;
import dji.common.mission.waypoint.WaypointMission;
import dji.common.mission.waypoint.WaypointMissionDownloadEvent;
import dji.common.mission.waypoint.WaypointMissionExecutionEvent;
import dji.common.mission.waypoint.WaypointMissionFinishedAction;
import dji.common.mission.waypoint.WaypointMissionFlightPathMode;
import dji.common.mission.waypoint.WaypointMissionHeadingMode;
import dji.common.mission.waypoint.WaypointMissionUploadEvent;
import dji.common.util.CommonCallbacks;
import dji.sdk.base.BaseProduct;
import dji.sdk.flightcontroller.FlightController;
import dji.sdk.mission.waypoint.WaypointMissionOperator;
import dji.sdk.mission.waypoint.WaypointMissionOperatorListener;
import dji.sdk.products.Aircraft;
import dji.sdk.sdkmanager.DJISDKManager;

public class GoogleMapActivity extends FragmentActivity implements View.OnClickListener, GoogleMap.OnMapClickListener, OnMapReadyCallback {
    private static final String TAG1 = "GoogleMapActivity";

//    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
//    private static final String COURSE_LCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
//    private boolean mLocationPermissionsGranted = false;
//    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;

    private static final float DEFAULT_ZOOM = 15f;

    private FusedLocationProviderClient mFusedLocationProviderClient;


    //variable to display the drone
    private double droneLocationLat = 37.300624, droneLocationLng = -121.956598;
    private Marker droneMarker = null;
    private FlightController mFlightController;


    // start and stop mission button
    private ImageView mStartBtn;
    private ImageView mLandingBtn;

    private GoogleMap gMap;
    private ImageView mGpsBtn;
    private ImageView mWaypointAdd;
    private ImageView mConfigSetting;
    private EditText mSearchText;

    //auto fly config setting for the drone
    private float mAlitude = 5.0f;
    private float mSpeed = 5.0f;
    private List<Waypoint> waypointList = new ArrayList<>();
    public static WaypointMission.Builder waypointMissionBuilder;
    private WaypointMissionOperator instance;
    private WaypointMissionFinishedAction mFinishedAction = WaypointMissionFinishedAction.NO_ACTION;
    private WaypointMissionHeadingMode mHeadingMode = WaypointMissionHeadingMode.AUTO;

    //variable to add the waypoint to the map
    private boolean waypointAdded = false;
    private final Map<Integer, Marker> waypointMarkersMap = new ConcurrentHashMap<Integer, Marker>();

    // use for test the routine 1, SJSU
    private List<Waypoint> SJSURoutine = new ArrayList<>();
    private final Map<Integer, Marker>routineMarkers = new ConcurrentHashMap<Integer, Marker>();


    private static final String[] RequirePermission = new String[]{

            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };


    protected BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            onProductConnectionChange();
        }
    };

    @Override
    protected void onResume(){
        super.onResume();
        initFlightController();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_map);

        //detect the connection status, register a broadcastReceiver
        IntentFilter filter = new IntentFilter();
        filter.addAction(FPVApplication.FLAG_CONNECTION_CHANGE);
        registerReceiver(mReceiver, filter);

        initUI();
        initMap();
        // used to upload the waypoint mission to drone
        //addListener();
        storePath1();

        addListener();
    }

    @Override
    protected void onDestroy() {
        //use to remove the loading waypoint from the drone
        removeListener();
        unregisterReceiver(mReceiver);

        super.onDestroy();
    }

    public void onReturn(View view){
        this.finish();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add: {
                toggleAddBtn();
                break;
            }

            case R.id.btn_gps: {
               // showSettingDialog();
                updateDroneLocation();
                updateMapCamera();

                break;
            }
            case R.id.btn_config : {
                showConfigSetting();
                break;
            }
            case R.id.btn_landing : {
                uploadWaypointMissions();
                startWaypointMission();
                break;
            }
            case R.id.btn_takeoff: {
                storePath1();
                showRoutine();
                break;
            }
            default: {
                break;
            }
        }

    }

    @Override
    public void onMapClick(LatLng latLng) {
        if(waypointAdded == true) {
            addWaypointToMap(latLng);
            Waypoint mWaypoint = new Waypoint(latLng.latitude, latLng.longitude, mAlitude);
            //adding the location point to the list, so the drone can fly along the path
            if(waypointMissionBuilder != null) {
                waypointList.add(mWaypoint);
                waypointMissionBuilder.waypointList(waypointList).waypointCount(waypointList.size());
            } else {
                waypointMissionBuilder = new WaypointMission.Builder();
                waypointList.add(mWaypoint);
                waypointMissionBuilder.waypointList(waypointList).waypointCount(waypointList.size());
            }
        }else {
            displayResultToast("The Position cannot be added to the map");
        }

    }

    private void addWaypointToMap(LatLng waypoint) {
        MarkerOptions posWaypoint = new MarkerOptions();
        posWaypoint.position(waypoint);
        posWaypoint.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
        Marker posMarker = gMap.addMarker(posWaypoint);
        waypointMarkersMap.put(waypointMarkersMap.size(), posMarker);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if (gMap == null) {
            gMap = googleMap;
            setUpMap();

           // getUserLocation();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            gMap.setMyLocationEnabled(false);
        }
    }
    private void setUpMap() {
        gMap.setOnMapClickListener(this);
    }


//    // to ask user for the location permission
//    private void getLocationPermission() {
//        String[] permissions = {
//                Manifest.permission.ACCESS_COARSE_LOCATION,
//                Manifest.permission.ACCESS_FINE_LOCATION
//        };
//        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
//                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
//            if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
//                    COURSE_LCATION) == PackageManager.PERMISSION_GRANTED) {
//                mLocationPermissionsGranted = true;
//            } else {
//                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
//            }
//        }else {
//            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        mLocationPermissionsGranted = false;
//        switch(requestCode) {
//            case LOCATION_PERMISSION_REQUEST_CODE: {
//                if(grantResults.length > 0) {
//                    for(int i = 0; i < grantResults.length; i++) {
//                        if(grantResults[i] != PackageManager.PERMISSION_GRANTED) {
//                            mLocationPermissionsGranted = false;
//                            return;
//                        }
//                    }
//                    mLocationPermissionsGranted = true;
//                }
//            }
//        }
//    }

    private void onProductConnectionChange() {
        initFlightController();
    }


    private void getUserLocation() {
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        try {
            Task location = mFusedLocationProviderClient.getLastLocation();
            location.addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()) {
                        Location currentLocation = (Location)task.getResult();
                        moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()),DEFAULT_ZOOM, "Drone");
                    } else{
                        Toast.makeText(GoogleMapActivity.this, "Unable to get current location", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }catch (SecurityException e) {
            Log.e(TAG1, "GET Device: SecurityException" + e.getMessage());
        }

    }

    // use to move the map carmera for display the location
    private void moveCamera(LatLng latLng, float zoom, String title) {
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));

        MarkerOptions options = new MarkerOptions().position(latLng).title(title);
        gMap.addMarker(options);
        hideKeyBoard();
    }
    //this is function use to auto track the drone location
    private void updateMapCamera() {
        LatLng dronePos = new LatLng(droneLocationLat, droneLocationLng);
        float zoomLevel = (float)18.0;
        CameraUpdate mapCamera = CameraUpdateFactory.newLatLngZoom(dronePos, zoomLevel);
        gMap.moveCamera(mapCamera);
    }

    //------------------------------------------------------------------------------------------------------------

    private void geoLocate() {
        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(this);
        List<Address> list = new ArrayList<>();
        try {
            list = geocoder.getFromLocationName(searchString, 1);
        }catch (IOException e){
            Toast.makeText(this, "seach result is wrong",Toast.LENGTH_SHORT).show();
        }

        if(list.size() > 0) {
            Address address = list.get(0);
            moveCamera(new LatLng(address.getLatitude(), address.getLongitude()),DEFAULT_ZOOM, address.getAddressLine(0));
        }

    }

    // this method used to get the drone location from brocadercast receiver
    private void initFlightController() {
        BaseProduct product = FPVApplication.getProductInstance();
        if (product != null && product.isConnected()) {
            if(product instanceof Aircraft) {
                mFlightController = ((Aircraft)product).getFlightController();
            }
        }

        if(mFlightController != null) {
            mFlightController.setStateCallback(new FlightControllerState.Callback() {
                @Override
                public void onUpdate(@NonNull FlightControllerState flightControllerState) {
                    droneLocationLat = flightControllerState.getAircraftLocation().getLatitude();
                    droneLocationLng = flightControllerState.getAircraftLocation().getLongitude();
                    // need to create a new method update drone location
                    updateDroneLocation();
                }
            });
        }
    }
    public static boolean checkGpsCoordination(double latitude, double longitude) {
        return (latitude > -90 && latitude < 90 && longitude > -180 && longitude < 180)
                && (latitude != 0f && longitude != 0f);
    }

    private void updateDroneLocation() {
        LatLng pos = new LatLng(droneLocationLat, droneLocationLng);

        //create the maker object
        final MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(pos);
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.aircraft));
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(droneMarker != null) {
                    droneMarker.remove();
                }

                if(checkGpsCoordination(droneLocationLat, droneLocationLng)) {
                    droneMarker = gMap.addMarker(markerOptions);
                }
            }
        });
    }

    //----------------------------------------------------------------------------------------------------------------------------------------

    private void showConfigSetting() {
        LinearLayout waypointSettings = (LinearLayout)getLayoutInflater().inflate(R.layout.waypoint_setting, null);
        final TextView altitude_box = (TextView)waypointSettings.findViewById(R.id.altitude);
        RadioGroup speed_RG = (RadioGroup)waypointSettings.findViewById(R.id.speed);
        RadioGroup actionAfterFinished_RG = (RadioGroup)waypointSettings.findViewById(R.id.actionAfterFinished);
        RadioGroup heading_RG = (RadioGroup) waypointSettings.findViewById(R.id.heading);

        speed_RG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.lowSpeed){
                    mSpeed = 3.0f;
                } else if(checkedId == R.id.MidSpeed) {
                    mSpeed = 5.0f;
                }else if(checkedId == R.id.HighSpeed) {
                    mSpeed = 10.0f;
                }
            }
        });
        actionAfterFinished_RG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.finishNone) {
                    mFinishedAction = WaypointMissionFinishedAction.NO_ACTION;
                } else if(checkedId == R.id.finishGoHome) {
                    mFinishedAction = WaypointMissionFinishedAction.GO_HOME;
                } else if(checkedId == R.id.finishAutoLanding) {
                    mFinishedAction = WaypointMissionFinishedAction.AUTO_LAND;
                } else if(checkedId == R.id.finishToFirst) {
                    mFinishedAction = WaypointMissionFinishedAction.GO_FIRST_WAYPOINT;
                }
            }
        });

        heading_RG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.headingNext) {
                    mHeadingMode = WaypointMissionHeadingMode.AUTO;
                } else if (checkedId == R.id.headingInitDirec) {
                    mHeadingMode = WaypointMissionHeadingMode.USING_INITIAL_DIRECTION;
                } else if(checkedId == R.id.headingRC) {
                    mHeadingMode = WaypointMissionHeadingMode.CONTROL_BY_REMOTE_CONTROLLER;
                } else if(checkedId == R.id.headingWP) {
                    mHeadingMode = WaypointMissionHeadingMode.USING_WAYPOINT_HEADING;
                }
            }
        });

        new AlertDialog.Builder(this)
                .setTitle("")
                .setView(waypointSettings)
                .setPositiveButton("Finish", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        String altitudeString = altitude_box.getText().toString();
                        mAlitude = Integer.parseInt(intCheck(altitudeString)); // ----> need to check it is int or not,--
                        Log.e(TAG1,"Altitude" + mAlitude);
                        Log.e(TAG1,"my speed" + mSpeed);
                        Log.e(TAG1,"my finish action" + mFinishedAction);
                        Log.e(TAG1, "my heading model" + mHeadingMode);
                        configWaypointSettings();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .create()
                .show();
    }


    public WaypointMissionOperator getWaypointMissionOperator() {
        if(instance == null) {
            if(DJISDKManager.getInstance().getMissionControl() != null) {
                instance = DJISDKManager.getInstance().getMissionControl().getWaypointMissionOperator();
            }
        }
        return instance;
    }

    private void configWaypointSettings() {
        if(waypointMissionBuilder == null) {
            waypointMissionBuilder = new WaypointMission.Builder().finishedAction(WaypointMissionFinishedAction.GO_HOME)
                                                                  .headingMode(WaypointMissionHeadingMode.AUTO)
                                                                  .autoFlightSpeed(5.0f)
                                                                  .maxFlightSpeed(8.0f)
                                                                  .flightPathMode(WaypointMissionFlightPathMode.NORMAL);
        } else {
            waypointMissionBuilder.finishedAction(WaypointMissionFinishedAction.GO_HOME)
                                  .headingMode(WaypointMissionHeadingMode.AUTO)
                                  .autoFlightSpeed(5.0f)
                                  .maxFlightSpeed(8.0f)
                                  .flightPathMode(WaypointMissionFlightPathMode.NORMAL);
        }
//        if(waypointMissionBuilder.getWaypointList().size() > 0) {
//            for(int i = 0; i < waypointMissionBuilder.getWaypointList().size(); i++) {
//                waypointMissionBuilder.getWaypointList().get(i).altitude = 10;
//            }
//            displayResultToast("Set Waypoint attidude successful");
//        }
        List<Waypoint> testingLocation = new ArrayList<>();
        testingLocation.add(new Waypoint(37.397803, -121.861198, 20f));
        testingLocation.add(new Waypoint(37.404090,-121.865376, 20f));
        testingLocation.add(new Waypoint(37.399273,-121.858617, 20f));
        if(waypointMissionBuilder.getWaypointList().size() > 0) {
            for(int i = 0; i < waypointMissionBuilder.getWaypointList().size(); i++) {
                waypointMissionBuilder.getWaypointList().get(i).altitude = 30.0f;
            }
            displayResultToast("Set Waypoint attidude successful");
        }

        waypointMissionBuilder.waypointList(testingLocation).waypointCount(testingLocation.size());
        WaypointMission builder = waypointMissionBuilder.build();
        DJIError  testError = getWaypointMissionOperator().loadMission(builder);
        if(testError == null) {
            displayResultToast("successful loading the waypoint mission");
        } else {
            displayResultToast("failed to load the waypoint mission" + testError.getDescription());
        }

        //waypointMissionBuilder.waypointList(SJSURoutine).

//        DJIError error = getWaypointMissionOperator().loadMission(waypointMissionBuilder.build());
//        if(error == null) {
//            displayResultToast("successful loading the waypoint mission");
//        } else {
//            displayResultToast("failed to load the waypoint mission" + error.getDescription());
//        }
    }
    //-------------------------------------------------------------------------------------------------


    // add listener for waypoint mission operator, used to upload the waypoint mission
    private void uploadWaypointMissions() {
        getWaypointMissionOperator().uploadMission(new CommonCallbacks.CompletionCallback() {
            @Override
            public void onResult(DJIError djiError) {
                if(djiError == null) {
                    displayResultToast("Mission upload successful!");
                } else {
                    displayResultToast("Mission upload failed, Error" + djiError.getDescription() + "retrying");
                    getWaypointMissionOperator().retryUploadMission(null);
                }
            }
        });
    }


    private void addListener() {
        if(getWaypointMissionOperator() != null) {
            getWaypointMissionOperator().addListener(eventNotificationListener);
        }
    }

    private void removeListener() {
        if(getWaypointMissionOperator() != null) {
            getWaypointMissionOperator().removeListener(eventNotificationListener);
        }
    }

    private WaypointMissionOperatorListener eventNotificationListener = new WaypointMissionOperatorListener() {
        @Override
        public void onDownloadUpdate(@NonNull WaypointMissionDownloadEvent waypointMissionDownloadEvent) {

        }

        @Override
        public void onUploadUpdate(@NonNull WaypointMissionUploadEvent waypointMissionUploadEvent) {

        }

        @Override
        public void onExecutionUpdate(@NonNull WaypointMissionExecutionEvent waypointMissionExecutionEvent) {

        }

        @Override
        public void onExecutionStart() {

        }

        @Override
        public void onExecutionFinish(@Nullable DJIError djiError) {
            displayResultToast("Execution has been finished" + (djiError == null ? "Successful" : djiError.getDescription()));
        }
    };

    //--------------------------------------------------------------------------------------------------------------------------
    // use to start and stop the waypoint missions
    private void startWaypointMission() {
        getWaypointMissionOperator().startMission(new CommonCallbacks.CompletionCallback() {
            @Override
            public void onResult(DJIError djiError) {
                displayResultToast("Mission Start" + (djiError == null ? "Successful" : djiError.getDescription()));
            }
        });
    }

    private void stopWaypointMission() {
        getWaypointMissionOperator().stopMission(new CommonCallbacks.CompletionCallback() {
            @Override
            public void onResult(DJIError djiError) {
                displayResultToast("Mission stop" + (djiError == null ? "Successful" : djiError.getDescription()));
            }
        });
    }

    //----------------------------------------------------------------------------------------------------------------
    // use for pre store the waypoint testing the sjsu routine
    private void  storePath1() {
        SJSURoutine.add(new Waypoint(37.335847, -121.886055,5));
        SJSURoutine.add(new Waypoint(37.336850, -121.883882,5));
        SJSURoutine.add(new Waypoint(37.337861, -121.881847,5));
        SJSURoutine.add(new Waypoint(37.338723, -121.879702,5));
        SJSURoutine.add(new Waypoint(37.337390, -121.878575,5));
        SJSURoutine.add(new Waypoint(37.334568, -121.876473,5));
        SJSURoutine.add(new Waypoint(37.333054, -121.879663,5));
        SJSURoutine.add(new Waypoint(37.331546, -121.882883,5));
        SJSURoutine.add(new Waypoint(37.332986, -121.883936,5));
        SJSURoutine.add(new Waypoint(37.334560, -121.885126,5));
    }

    private void showRoutine() {
        for(int i = 0; i < SJSURoutine.size(); i++) {
            double lati = SJSURoutine.get(i).coordinate.getLatitude();
            double lonti = SJSURoutine.get(i).coordinate.getLongitude();
            MarkerOptions markers = new MarkerOptions();
            markers.position(new LatLng(lati, lonti));
            markers.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
            Marker marker = gMap.addMarker(markers);
            routineMarkers.put(routineMarkers.size(), marker);
        }
        moveCamera(new LatLng(SJSURoutine.get(0).coordinate.getLatitude(), SJSURoutine.get(0).coordinate.getLongitude()),DEFAULT_ZOOM,"SJSU routine");
    }









    //----------------------------------------------------------------------------------------------------------------


    private void initMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    private void initUI() {

        mStartBtn = (ImageView) findViewById(R.id.btn_takeoff);
        mLandingBtn = (ImageView) findViewById(R.id.btn_landing);
        mGpsBtn = (ImageView) findViewById(R.id.btn_gps);
        mWaypointAdd = (ImageView) findViewById(R.id.btn_add);
        mConfigSetting = (ImageView) findViewById(R.id.btn_config);

        mStartBtn.setOnClickListener(this);
        mLandingBtn.setOnClickListener(this);

        mGpsBtn.setOnClickListener(this);
        mGpsBtn.getBackground().setAlpha(200);
        mWaypointAdd.setOnClickListener(this);
        mWaypointAdd.getBackground().setAlpha(50);
        mConfigSetting.setOnClickListener(this);
        mConfigSetting.getBackground().setAlpha(250);

        mSearchText = (EditText) findViewById(R.id.input_search);
        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || event.getAction() == KeyEvent.ACTION_DOWN
                        ||event.getAction() == KeyEvent.KEYCODE_ENTER) {
                    // exectute the seaching method;
                    geoLocate();
                }
                    return false;
                }
        });

        hideKeyBoard();
    }

    private void toggleAddBtn() {
        if(waypointAdded == false) {
            waypointAdded = true;
            mWaypointAdd.setImageResource(R.drawable.ic_location_off);

        } else {
            waypointAdded = false;
            mWaypointAdd.setImageResource(R.drawable.ic_add_waypoint);
            GoogleMapActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    gMap.clear();
                }
            });
            waypointList.clear();
            waypointMissionBuilder.waypointList(waypointList).waypointCount(0);
            updateDroneLocation();
        }
    }


    private void hideKeyBoard() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    // to check the input value is int or no
    String intCheck(String val) {
        if(!isIntValue(val)) {
            val = "0";
        }
        return val;
    }

    boolean isIntValue(String value) {
        try {
            value = value.replace(" ", "");
            Integer.parseInt(value);
        }catch (Exception e) {
            return false;
        }
        return true;
    }

    // to display the toast sentence to user
    private void displayResultToast(final String toast) {
        GoogleMapActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(GoogleMapActivity.this, toast, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
