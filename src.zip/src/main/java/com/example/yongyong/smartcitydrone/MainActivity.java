package com.example.yongyong.smartcitydrone;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.SurfaceTexture;
import android.location.Location;
import android.media.Image;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import android.support.v4.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import dji.common.camera.SettingsDefinitions;
import dji.common.camera.SystemState;
import dji.common.error.DJIError;
import dji.common.product.Model;
import dji.common.realname.AircraftBindingState;
import dji.common.realname.AppActivationState;
import dji.common.useraccount.UserAccountState;
import dji.common.util.CommonCallbacks;
import dji.sdk.base.BaseProduct;
import dji.sdk.camera.Camera;
import dji.sdk.camera.VideoFeeder;
import dji.sdk.codec.DJICodecManager;
import dji.sdk.realname.AppActivationManager;
import dji.sdk.sdkmanager.DJISDKManager;
import dji.sdk.useraccount.UserAccountManager;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener, View.OnClickListener {

    private static final String TAG = MainActivity.class.getName();
    protected VideoFeeder.VideoDataCallback mReceivedVideoDataCallBack = null;

    protected DJICodecManager mCodecManager = null;

    protected TextureView mVideoSurface = null;
    private ImageView mCaptureBtn;
    private ImageView mShootPhotoModeBtn, mRecordVideoModeBtn;
    private ImageView mRecordBtn;
    private TextView recordingTime;

    private Handler handler;

    private boolean onOffVideocam = false;

    private FrameLayout mFrame;

//    //------------------------------------------------------------------------------------------------
//    //private FusedLocationProviderClient mFusedLocationProviderClient;
//    private GoogleMap mgMapView;
//    float DEFAULT_ZOOM = (float)18.0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        handler = new Handler();

        setContentView(R.layout.activity_main);
        initUI();
        //getUserLocation();

        mReceivedVideoDataCallBack = new VideoFeeder.VideoDataCallback() {
            @Override
            public void onReceive(byte[] videoBuffer, int size) {
                if (mCodecManager != null) {
                    mCodecManager.sendDataToDecoder(videoBuffer, size);
                }
            }
        };

        Camera camera = FPVApplication.getCameraInstance();

        if (camera != null) {

            camera.setSystemStateCallback(new SystemState.Callback() {
                @Override
                public void onUpdate(SystemState cameraSystemState) {
                    if (null != cameraSystemState) {

                        int recordTime = cameraSystemState.getCurrentVideoRecordingTimeInSeconds();
                        int minutes = (recordTime % 3600) / 60;
                        int seconds = recordTime % 60;

                        final String timeString = String.format("%02d:%02d", minutes, seconds);
                        final boolean isVideoRecording = cameraSystemState.isRecording();

                        MainActivity.this.runOnUiThread(new Runnable() {

                            @Override
                            public void run() {

                                recordingTime.setText(timeString);

                                /*
                                 * Update recordingTime TextView visibility and mRecordBtn's check state
                                 */
                                if (isVideoRecording){
                                    recordingTime.setVisibility(View.VISIBLE);
                                }else
                                {
                                    recordingTime.setVisibility(View.INVISIBLE);
                                }
                            }
                        });
                    }
                }
            });

        }
    }

    protected void onProductChange() {
        initPreviewer();
       // loginAccount();
    }

//    private void loginAccount(){
//
//        UserAccountManager.getInstance().logIntoDJIUserAccount(this,
//                new CommonCallbacks.CompletionCallbackWith<UserAccountState>() {
//                    @Override
//                    public void onSuccess(final UserAccountState userAccountState) {
//                        Log.e(TAG, "Login Success");
//                    }
//                    @Override
//                    public void onFailure(DJIError error) {
//                        showToast("Login Error:"
//                                + error.getDescription());
//                    }
//                });
//    }

    @Override
    public void onResume() {
        super.onResume();
        initPreviewer();
        onProductChange();

        if(mVideoSurface == null) {
            Log.e(TAG, "mVideoSurface is null");
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public void onReturn(View view){
        this.finish();
    }

    @Override
    protected void onDestroy() {
        uninitPreviewer();
        super.onDestroy();
    }


    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        Log.e(TAG, "onSurfaceTextureAvailable");
        if (mCodecManager == null) {
            mCodecManager = new DJICodecManager(this, surface, width, height);
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        Log.e(TAG, "onSurfaceTextureSizeChanged");
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
        Log.e(TAG,"onSurfaceTextureDestroyed");
        if (mCodecManager != null) {
            mCodecManager.cleanSurface();
            mCodecManager = null;
        }
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_capture:{
                captureAction();
                break;
            }
            case R.id.btn_shoot_photo_mode:{
                switchCameraMode(SettingsDefinitions.CameraMode.SHOOT_PHOTO);
                break;
            }
            case R.id.btn_record_video_mode:{
                switchCameraMode(SettingsDefinitions.CameraMode.RECORD_VIDEO);
                break;
            }
            case R.id.btn_record: {
                switchVideocam();
                break;
            }
            case R.id.frameLayout:{
                Intent intent = new Intent(this, GoogleMapActivity.class);
                startActivity(intent);
                break;
            }
            default:
                break;
        }
    }

//    private void mapInit () {
//        mapViewFrag = (SupportMapFragment) ().findFragmentById(R.id.map_fragview);
//        mapViewFrag.getMapAsync((OnMapReadyCallback) this);
//    }


    private void initUI() {
        // init mVideoSurface
        mVideoSurface = (TextureView)findViewById(R.id.video_previewer_surface);

        recordingTime = (TextView) findViewById(R.id.timer);
        mCaptureBtn = (ImageView) findViewById(R.id.btn_capture);
        mRecordBtn = (ImageView) findViewById(R.id.btn_record);
        mShootPhotoModeBtn = (ImageView) findViewById(R.id.btn_shoot_photo_mode);
        mRecordVideoModeBtn = (ImageView) findViewById(R.id.btn_record_video_mode);

        mFrame = (FrameLayout) findViewById(R.id.frameLayout);

        if (null != mVideoSurface) {
            mVideoSurface.setSurfaceTextureListener(this);
        }

        mCaptureBtn.setOnClickListener(this);
        mRecordBtn.setOnClickListener(this);
        mShootPhotoModeBtn.setOnClickListener(this);
        mRecordVideoModeBtn.setOnClickListener(this);
        mFrame.setOnClickListener(this);

        recordingTime.setVisibility(View.INVISIBLE);

//        mRecordBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if (isChecked) {
//                    startRecord();
//                } else {
//                    stopRecord();
//                }
//            }
//        });
    }

    private void initPreviewer() {

        BaseProduct product = FPVApplication.getProductInstance();

        if (product == null || !product.isConnected()) {
            showToast(getString(R.string.disconnected));
        } else {
            if (null != mVideoSurface) {
                mVideoSurface.setSurfaceTextureListener(this);
            }
            if (!product.getModel().equals(Model.UNKNOWN_AIRCRAFT)) {
                VideoFeeder.getInstance().getPrimaryVideoFeed().setCallback(mReceivedVideoDataCallBack);
            }
        }
    }

    private void uninitPreviewer() {
        Camera camera = FPVApplication.getCameraInstance();
        if (camera != null){
            // Reset the callback
            VideoFeeder.getInstance().getPrimaryVideoFeed().setCallback(null);
        }
    }


    // Method for starting recording
    private void startRecord(){

        final Camera camera = FPVApplication.getCameraInstance();
        if (camera != null) {
            camera.startRecordVideo(new CommonCallbacks.CompletionCallback(){
                @Override
                public void onResult(DJIError djiError)
                {
                    if (djiError == null) {
                        showToast("Record video: success");
                    }else {
                        showToast(djiError.getDescription());
                    }
                }
            }); // Execute the startRecordVideo API
        }
    }


    // Method for stopping recording
    private void stopRecord(){

        Camera camera = FPVApplication.getCameraInstance();
        if (camera != null) {
            camera.stopRecordVideo(new CommonCallbacks.CompletionCallback(){

                @Override
                public void onResult(DJIError djiError)
                {
                    if(djiError == null) {
                        showToast("Stop recording: success");
                    }else {
                        showToast(djiError.getDescription());
                    }
                }
            }); // Execute the stopRecordVideo API
        }

    }


    // Method for taking photo
    private void captureAction(){

        final Camera camera = FPVApplication.getCameraInstance();
        if (camera != null) {

            SettingsDefinitions.ShootPhotoMode photoMode = SettingsDefinitions.ShootPhotoMode.SINGLE; // Set the camera capture mode as Single mode
            camera.setShootPhotoMode(photoMode, new CommonCallbacks.CompletionCallback(){
                @Override
                public void onResult(DJIError djiError) {
                    if (null == djiError) {
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                camera.startShootPhoto(new CommonCallbacks.CompletionCallback() {
                                    @Override
                                    public void onResult(DJIError djiError) {
                                        if (djiError == null) {
                                            showToast("take photo: success");
                                        } else {
                                            showToast(djiError.getDescription());
                                        }
                                    }
                                });
                            }
                        }, 2000);
                    }
                }
            });
        }
    }

    private void switchCameraMode(SettingsDefinitions.CameraMode cameraMode){

        Camera camera = FPVApplication.getCameraInstance();
        if (camera != null) {
            camera.setMode(cameraMode, new CommonCallbacks.CompletionCallback() {
                @Override
                public void onResult(DJIError error) {

                    if (error == null) {
                        showToast("Switch Camera Mode Succeeded");
                    } else {
                        showToast(error.getDescription());
                    }
                }
            });
        }
    }

    private void switchVideocam() {
        if(onOffVideocam == false) {
            onOffVideocam = true;
            mRecordBtn.setImageResource(R.drawable.video_off);
            startRecord();
        } else {
            onOffVideocam = false;
            mRecordBtn.setImageResource(R.drawable.video_on);
            stopRecord();
        }
    }
    //-------------------------------------------------------------------------------------------------------
//    private void getUserLocation() {
//        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
//        try {
//            Task location = mFusedLocationProviderClient.getLastLocation();
//            location.addOnCompleteListener(new OnCompleteListener() {
//                @Override
//                public void onComplete(@NonNull Task task) {
//                    if(task.isSuccessful()) {
//                        Location currentLocation = (Location)task.getResult();
//                        moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()),DEFAULT_ZOOM, "Drone");
//                    } else{
//                        Toast.makeText(MainActivity.this, "Unable to get current location", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }catch (SecurityException e) {
//            Log.e(TAG, "GET Device: SecurityException" + e.getMessage());
//        }
//    }

//    private void moveCamera(LatLng latLng, float zoom, String title) {
//        mgMapView.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
//
//        MarkerOptions options = new MarkerOptions().position(latLng).title(title);
//        mgMapView.addMarker(options);
//    }




    //-------------------------------------------------------------------------------------------------------


    private void showToast(final String toastMsg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), toastMsg, Toast.LENGTH_LONG).show();

            }
        });
    }
//
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        if(mgMapView == null) {
//            mgMapView = googleMap;
//        }
//        LatLng sjsu = new LatLng(37.335187, -121.881072);
//        mgMapView.addMarker(new MarkerOptions().position(sjsu).title("SJSU"));
//        mgMapView.moveCamera(CameraUpdateFactory.newLatLngZoom(sjsu, DEFAULT_ZOOM));
//    }

}

